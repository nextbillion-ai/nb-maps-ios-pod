#pragma once

#import <Foundation/Foundation.h>

#define NGL_EXPORT __attribute__((visibility ("default")))
